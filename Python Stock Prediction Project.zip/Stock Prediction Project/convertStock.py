#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 11 14:06:20 2020

@author: jixingman
"""


import os



ticker='MA'
input_dir = r'/Users/jixingman/Desktop/cs 677'
ticker_file = os.path.join(input_dir, ticker + '.csv')

try:   
    with open(ticker_file) as f:
        lines = f.read().splitlines()
    print('opened file for ticker: ', ticker)
    """    your code for assignment 1 goes here

    """
   
    
    words = [lines.split(',')  for lines in lines]

    def column(matrix, i):
        return [row[i] for row in matrix]
    x = words[1:]
    print(x)
    y = (column(x,13))

# get mean for each weekday
    R_num = y
    for i in range(0, len(R_num)): 
        R_num[i] = float(R_num[i]) 
    R = len(R_num)
    print(R)
    R_sum = sum(R_num)
    print(R_sum)
# filter out weekday and year

    

    
except Exception as e:
    print(e)
    print('failed to read stock data for ticker: ', ticker)
    

